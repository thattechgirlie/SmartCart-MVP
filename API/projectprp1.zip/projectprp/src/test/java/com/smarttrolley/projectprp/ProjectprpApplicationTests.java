package com.smarttrolley.projectprp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectprpApplicationTests {

	@Test
	void contextLoads() {
	}

}
