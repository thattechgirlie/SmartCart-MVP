package com.smarttrolley.projectprp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectprpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectprpApplication.class, args);
	}

}
